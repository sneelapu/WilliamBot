This is the folder which had the R&D and the trained model.
OrderBot is the model Trained to the LUIS
webChat.html is the file used for implementing the chat using webchat.
Api.js in the API folder is used for getting response text when used different server for it.