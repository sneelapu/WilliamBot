var restify = require('restify');
var builder = require('botbuilder');
var LUIS = require('luis-sdk');
var moment = require('moment');
var ping = require("ping");
var unirest = require("unirest");

var bot = new builder.UniversalBot(connector);
var server = restify.createServer();
server.listen(process.env.port || process.env.PORT || 3000, function () {
    console.log("--------------------------------------------------------");
    console.log(moment().format('MMMM Do YYYY, hh🇲🇲ss a') + " | Kohler is running with the address : " + server.url);
    console.log("--------------------------------------------------------");
});
var connector = new builder.ChatConnector({
    appId: "80fa87c4-658d-48b9-ad65-853144ebdca1",
    appPassword: "trsGOWE926^@;cyzoTBD25}"
});
var dataStore = [{}];
var p = 0;

var Data = [
    {
        "modelNumber": "8956232",
        "orderNumber": "o986601",
        "deliveryStatus ": "DISPATCHED",
        "fName": "akash",
        "lName": "pavate",
        "name": "Akash Pavate",
        "dateOfPurchase": "02-22-2019",
        "Item": "Cuff Dual-handle wall-mount Kitchen mixer",
        "Qty": "1",
        "Price": "6,960",
        "lineTotal": "6,960",
        "finalTotal": "6,960",
        "warrantyPeriod": "4 years"

    },
    {
        "modelNumber": "8956212",
        "orderNumber": "o128967",
        "deliveryStatus ": "Shipped",
        "dateOfPurchase": "03-03-2019",
        "fName": "pavani",
        "lName": "moturi",
        "name": "Pavani Moturi",
        "Item": "Elate Kitchen sink faucet in Vibrant stainless steel",
        "Qty": "1",
        "Price": "6,610",
        "lineTotal": "6,610",
        "finalTotal": "6,610",
        "warrantyPeriod": "4 years"
    },
    {
        "modelNumber": "9256232",
        "orderNumber": "o976584",
        "deliveryStatus ": "COMPLETE",
        "dateOfPurchase": "03-10-2019",
        "Item": "40 mm Shower only Trim",
        "Qty": "1",
        "fName": "chanakya",
        "lName": "lokam",
        "name": "Chanakya Lokam",
        "Price": "3,130.00",
        "lineTotal": "3,130.00",
        "finalTotal": "3,130.00",
        "warrantyPeriod": "2 years"
    },
    {
        "modelNumber": "7646232",
        "orderNumber": "o098724",
        "deliveryStatus ": "Packed",
        "dateOfPurchase": "02-15-2019",
        "Item": "Long handle kitchen sink faucet (cyclic valve)",
        "Qty": "1",
        "fName": "akash",
        "lName": "pavate",
        "name": "Akash Pavate",
        "Price": "12,440.00",
        "lineTotal": "12,440.00",
        "finalTotal": "12,440.00",
        "warrantyPeriod": "5 years"
    },
    {
        "modelNumber": "6753498",
        "orderNumber": "o564378",
        "deliveryStatus ": "COMPLETE",
        "dateOfPurchase": "02-17-2019",
        "Item": "Dual-handle wall-mount kitchen mixer",
        "Qty": "1",
        "fName": "chanakya",
        "lName": "lokam",
        "name": "Chanakya Lokam",
        "Price": "15,370.00",
        "lineTotal": "15,370.00",
        "finalTotal": "15,370.00",
        "warrantyPeriod": "3 years"
    }
]
server.use(restify.conditionalRequest());
//var bot = new builder.UniversalBot(connector);
var bot = new builder.UniversalBot(connector, {
    storage: new builder.MemoryBotStorage()
});
var model = 'https://westus.api.cognitive.microsoft.com/luis/v2.0/apps/af9f9d58-e570-4519-9a1e-a03a802b93d1?verbose=true&timezoneOffset=-360&subscription-key=6d3d1738a14b470994758b2b8a889c02&q=';

var recognizer = new builder.LuisRecognizer(model);
var dialog = new builder.IntentDialog({
    recognizers: [recognizer]
});
var count = 0;
var n = 0;
server.post('/api/messages', connector.listen());
bot.dialog('/', dialog);

server.get(/.*/, restify.serveStatic({
    'directory': __dirname + '/',
    'default': 'index.html'
}));
function getCardsAttachments2(session) {
    return [
        new builder.HeroCard(session)
            .buttons([
                builder.CardAction.imBack(session, "Retrieve Order Status", "Retrieve Order Status"),
                builder.CardAction.imBack(session, 'Request Shipping & Delivery status', "Request Shipping & Delivery status"),
                builder.CardAction.imBack(session, 'Provide warranty information', "Provide warranty information"),
                builder.CardAction.imBack(session, 'Provide nearby stores information', "Provide nearby stores information"),
                builder.CardAction.imBack(session, 'Identify Equipment', "Identify Equipment"),

            ]),
    ];
}
function getCardsAttachments3(session) {
    console.log("Session ", session);
    return [
        new builder.HeroCard(session)
            .title('Name : ' + session.name)
            .subtitle('Date Of Purchase : ' + session.dateOfPurchase)
            .buttons([
                builder.CardAction.imBack(session, session.orderNumber, session.orderNumber)

            ]),
    ];
}
function storeLocator(session) {
    console.log("Session ", session);
    return [
        new builder.HeroCard(session)
            .text('Click here for more Information')
            .buttons([
                builder.CardAction.openUrl(session, 'https://www.us.kohler.com/us/storelocator/storeLocator.jsp', 'Store locator')

            ]),
    ];
}

function createReceiptCard1(session) {
    return new builder.ReceiptCard(session)
        .buttons([
            builder.CardAction.openUrl(session, 'https://www.us.kohler.com/us/storelocator/storeLocator.jsp', 'Store locator')
        ]);
}
function createReceiptCard(session) {
    return new builder.ReceiptCard(session)
        .title(session.name)
        .facts([
            builder.Fact.create(session, session.orderNumber, 'Order Number'),
            builder.Fact.create(session, session.dateOfPurchase, 'Date of Purchase'),
            builder.Fact.create(session, session.Item, 'Item'),
            builder.Fact.create(session, session.Qty, 'Quantity'),
            builder.Fact.create(session, session.lineTotal, 'Line Total'),
        ])
        .total(session.finalTotal)
}
function getCardsAttachments(session) {
    console.log("getCardsAttachments", session)

    // return [
    //     new builder.ThumbnailCard().title("Hai").subtitle("Hello").
    //     text("Patient Name : "+"\n"+"Date : "+"Time : "+" PST\n"+"address : ")
    //    // images([builder.CardImage.create(session,${scenarioArgs}.imageURL)])
    // ] 
    return [
        new builder.HeroCard(session)
            .title('Order Number : ' + session.orderNumber)
            .subtitle('Name : ' + session.name)
            .text("Date of Purchase : " + session.dateOfPurchase + " \n Item : " + session.Item + " \n Quantity : " + session.Qty + " \n Line Total : " + session.lineTotal + " \n Final Total : " + session.finalTotal)
        // new builder.ThumbnailCard().title('Name : '+ session.name).subtitle('Date Of Purchase : '+session.dateOfPurchase+"\n Quantity : " + session.Qty).
        // text("Date of Purchase : " + session.dateOfPurchase + " \n "+"Item : " + session.Item + " \n Quantity : " + session.Qty + " \n Line Total : " + session.lineTotal + " \n Final Total : " + session.finalTotal)
    ];
}
//Greetings intent matches
dialog.matches('Greetings', [
    function (session, args) {
        session.sendTyping();
        console.log(session, args);
        console.log("--------------------------------------------------------");
        console.log(moment().format('MMMM Do YYYY, hh🇲🇲ss a') + " | Greetings Intent Matched");
        console.log("--------------------------------------------------------");
        session.send("Hi I’m William- The Agent Assistance Bot. How can I help you today?");

    }
]);
//Capabilities intent matches
dialog.matches('Capabilities', [
    function (session, args) {
        session.sendTyping();
        session.send("I can help you with the following")
        var cards = getCardsAttachments2();
        var reply = new builder.Message(session)
            .attachmentLayout(builder.AttachmentLayout.carousel)
            .attachments(cards);
        session.send(reply);

    }

]);
//order Number
dialog.matches('OrderNumber', [
    function (session, args) {
        session.sendTyping();
        Data.forEach(element => {
            if (element.orderNumber == args.entities[0].entity) {
                session.orderNumber = element.orderNumber
                session.dateOfPurchase = element.dateOfPurchase
                session.fName = element.fName
                session.lName = element.lName
                session.finalTotal = element.finalTotal
                session.Item = element.Item
                session.Qty = element.Qty
                session.name = element.name
                session.lineTotal = element.lineTotal
                var selectedCardName = createReceiptCard
                var card = createCard(selectedCardName, session);
                var msg = new builder.Message(session).addAttachment(card);
                session.send(msg);

            }

        });


    }

]);
//OrderStats 
const HeroCardName = 'Hero card';
const ThumbnailCardName = 'Thumbnail card';
const ReceiptCardName = 'Receipt card';
const ReceiptCardName1 = 'Reciept Card1';
const SigninCardName = 'Sign-in card';
const CardNames = [HeroCardName, ThumbnailCardName, ReceiptCardName, SigninCardName];
function createCard(selectedCardName, session) {
    switch (selectedCardName) {

        case ReceiptCardName:
            return createReceiptCard(session);
        case ReceiptCardName1:
            return createReceiptCard1(session);
        default:
            return createReceiptCard(session);
    }
}
dialog.matches('Order', [
    function (session, args) {
        session.sendTyping();
        //   console.log("args", args);
        if (args.entities.length == 0) {
            // console.log("session",session);
            session.beginDialog('/orderWithDetails', session)

        }
        else {
            console.log("args", args)
            var count = 0;
            if (args.entities[0].type == "builtin.personName") {
                Data.forEach(element => {
                    console.log("Inside for");
                    if (element.lName == args.entities[0].entity) {
                        console.log("inside if", count);
                        count++;
                    }
                });
                console.log("After for", count);
                if (count == 1) {
                    console.log("inside count =1");
                    Data.forEach(element => {
                        if (element.lName == args.entities[0].entity) {
                            session.orderNumber = element.orderNumber
                            session.dateOfPurchase = element.dateOfPurchase
                            session.fName = element.fName
                            session.lName = element.lName
                            session.finalTotal = element.finalTotal
                            session.Item = element.Item
                            session.Qty = element.Qty
                            session.name = element.name
                            session.lineTotal = element.lineTotal
                            var selectedCardName = createReceiptCard
                            var card = createCard(selectedCardName, session);
                            var msg = new builder.Message(session).addAttachment(card);
                            session.send(msg);
                            // var cards = getCardsAttachments(session);
                            // var reply = new builder.Message(session)
                            //     .attachmentLayout(builder.AttachmentLayout.carousel)
                            //     .attachments(cards);
                            // session.send(reply);

                        }
                    });
                }
                else {
                    session.send("We found " + count + " number of orders")
                    Data.forEach(element => {
                        if (element.lName == args.entities[0].entity) {
                            session.orderNumber = element.orderNumber
                            session.orderNumber = element.orderNumber
                            session.dateOfPurchase = element.dateOfPurchase
                            session.fName = element.fName
                            session.lName = element.lName
                            session.finalTotal = element.finalTotal
                            session.Item = element.Item
                            session.Qty = element.Qty
                            session.name = element.name
                            session.lineTotal = element.lineTotal

                            var cards = getCardsAttachments3(session);
                            var reply = new builder.Message(session)
                                .attachmentLayout(builder.AttachmentLayout.carousel)
                                .attachments(cards);
                            session.send(reply);

                        }
                    });

                }
            }
            else {
                Data.forEach(element => {
                    if (element.orderNumber == args.entities[0].entity) {
                        session.orderNumber = element.orderNumber
                        session.dateOfPurchase = element.dateOfPurchase
                        session.fName = element.fName
                        session.lName = element.lName
                        session.finalTotal = element.finalTotal
                        session.Item = element.Item
                        session.Qty = element.Qty
                        session.name = element.name
                        session.lineTotal = element.lineTotal
                        var selectedCardName = createReceiptCard
                        var card = createCard(selectedCardName, session);
                        var msg = new builder.Message(session).addAttachment(card);
                        session.send(msg);
                        // var cards = getCardsAttachments(session);
                        // var reply = new builder.Message(session)
                        //     .attachmentLayout(builder.AttachmentLayout.carousel)
                        //     .attachments(cards);
                        // session.send(reply);

                    }

                });
                // session.send(" Still Working for Number");
            }

        }



    }
]);
bot.dialog('/orderWithDetails', [
    function (session, args) {
        session.sendTyping();
        builder.Prompts.text(session, "Enter Customer order number");
    },
    function (session, args) {
        console.log("args", args);
        Data.forEach(element => {
            if (element.orderNumber == args.response) {
                count++;
            }
        });
        if (count == 1) {
            Data.forEach(element => {
                if (element.orderNumber == args.response) {
                    session.orderNumber = element.orderNumber
                    session.dateOfPurchase = element.dateOfPurchase
                    session.fName = element.fName
                    session.lName = element.lName
                    session.finalTotal = element.finalTotal
                    session.Item = element.Item
                    session.Qty = element.Qty
                    session.name = element.name
                    session.lineTotal = element.lineTotal
                    var selectedCardName = createReceiptCard
                    var card = createCard(selectedCardName, session);
                    var msg = new builder.Message(session).addAttachment(card);
                    session.send(msg);
                    // var cards = getCardsAttachments(session);
                    // var reply = new builder.Message(session)
                    //     .attachmentLayout(builder.AttachmentLayout.carousel)
                    //     .attachments(cards);
                    // session.send(reply);

                }
            });
        }
        else {
            Data.forEach(element => {
                if (element.orderNumber == args.response) {
                    session.orderNumber = element.orderNumber
                    session.dateOfPurchase = element.dateOfPurchase
                    session.fName = element.fName
                    session.lName = element.lName
                    session.finalTotal = element.finalTotal
                    session.Item = element.Item
                    session.Qty = element.Qty
                    session.name = element.name
                    session.lineTotal = element.lineTotal
                    var selectedCardName = createReceiptCard
                    var card = createCard(selectedCardName, session);
                    var msg = new builder.Message(session).addAttachment(card);
                    session.send(msg);
                    // var cards = getCardsAttachments(session);
                    // var reply = new builder.Message(session)
                    //     .attachmentLayout(builder.AttachmentLayout.carousel)
                    //     .attachments(cards);
                    // session.send(reply);

                }
            });

        }
        session.endDialog();
        session.endConversation();
    }

]);



dialog.matches('Warranty', [
    function (session, args) {
        session.sendTyping();
        console.log("args", args);
        if (args.entities.length == 0) {
            session.beginDialog('/WarrantywithDetails', session)

        }
        else {
            Data.forEach(element => {

                if (element.modelNumber == args.entities[0].entity) {
                    //  console.log("element.deliveryStatus", element.deliveryStatus);
                    session.send("The warranty period of model  " + args.entities[0].entity + " is  " + element.warrantyPeriod);

                }

            });
        }




    }
]);
bot.dialog('/WarrantywithDetails', [
    function (session, args) {
        session.sendTyping();
        builder.Prompts.text(session, "Enter product model number or upload the image");
    },
    function (session, args) {
        console.log("args", args);
        Data.forEach(element => {
            if (element.modelNumber == args.response) {
                console.log("element", element);
                session.send("The warranty period of model  " + args.response + " is  " + element.warrantyPeriod);


            }
        });
        session.endDialog();
        session.endConversation();

    }


])

dialog.matches('Tracking', [
    function (session, args) {
        session.sendTyping();
        console.log("args", args);
        if (args.entities.length == 0) {
            session.beginDialog('/TrackingwithDetails', session)

        }
        else {

            console.log("args", args)

            if (args.entities[0].type == "builtin.personName") {
                Data.forEach(element => {
                    if (element.lName == args.entities[0].entity) {

                        session.send("The delivery status of order " + args.entities[0].entity + " is " + element["deliveryStatus "]);
                    }

                });
                // session.send(" Still Working for Last Name");
            }
            else {
                Data.forEach(element => {

                    if (element.orderNumber == args.entities[0].entity) {
                        console.log("element.deliveryStatus", element.deliveryStatus);
                        session.send("The delivery status of order " + args.entities[0].entity + " is  " + element["deliveryStatus "]);

                    }

                });
                // session.send(" Still Working for Number");
            }

        }



    }
]);
bot.dialog('/TrackingwithDetails', [
    function (session, args) {
        session.sendTyping();
        builder.Prompts.text(session, "Enter your Order number");
    },
    function (session, args) {
        console.log("args", args);
        Data.forEach(element => {
            if (element.orderNumber == args.response) {
                console.log("element", element);
                session.send("The delivery status of order " + args.response + " is " + element["deliveryStatus "]);


            }
        });
        session.endDialog();
        session.endConversation();

    }


])

dialog.matches('StoreLocator', [
    function (session, args) {
        session.sendTyping();
        // var selectedCardName = ReceiptCardName1
        // var card = createCard(selectedCardName, session);
        // var msg = new builder.Message(session).addAttachment(card);
        // session.send(msg);
     
        var cards = storeLocator(session);
        var reply = new builder.Message(session)
            .attachmentLayout(builder.AttachmentLayout.carousel)
            .attachments(cards);
        session.send(reply);;
        session.endDialog();
        session.endConversation();
        // session.send("Working on store locater");
    }
]);

dialog.matches('Thank you', [
    function (session, args) {
        session.sendTyping();
        console.log("--------------------------------------------------------");
        console.log(moment().format('MMMM Do YYYY, hh🇲🇲ss a') + " | Thank you Intent Matched");
        console.log("--------------------------------------------------------");
        session.send("My pleasure! Let me know if you need anything else.");
    }
]);

dialog.matches('conformation', [
    function (session, args) {
        session.sendTyping();
        console.log("--------------------------------------------------------");
        console.log(moment().format('MMMM Do YYYY, hh🇲🇲ss a') + " | Thank you Intent Matched");
        console.log("--------------------------------------------------------");
        session.send("Thanks, have a great day.");
    }
]);

dialog.onDefault(builder.DialogAction.send("Sorry, trouble understanding you.I can help you Order and Delivery statues "));