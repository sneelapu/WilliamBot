var restify = require('restify');
var builder = require('botbuilder');
var LUIS = require('luis-sdk');
var moment = require('moment');
var ping = require("ping");
var unirest = require("unirest");
const request = require('request-promise')
var globalOrder = null;
var bot = new builder.UniversalBot(connector);
var server = restify.createServer();
server.listen(process.env.port || process.env.PORT || 3000, function () {
    console.log("--------------------------------------------------------");
    console.log(moment().format('MMMM Do YYYY, hh🇲🇲ss a') + " | Kohler is running with the address : " + server.url);
    console.log("--------------------------------------------------------");
});
var connector = new builder.ChatConnector({
    appId: "d0392a19-54c6-45e1-8f4a-72c5c0335960",
    appPassword: "wfencaLIMAE988]lRN74]^}"
});
var dataStore = [{}];
var p = 0;

var Data1 = [
    {
        "Category": "Kitchen",
        "ProductType": "kitchen faucets",
        "ProductName": "semiprofessional kitchen sink faucet",
        "modelNumber": "K2498",
        "WarrantyPeriod": "2",
        "ImageUrl": "https://drive.google.com/open?id=1yxMRlfDnZ-M4x2xTvckSDaNzvGub-sGN",

    },
    {
        "Category": "Bathroom",
        "ProductType": "bathroom sinks",
        "ProductName": "Oval mirror",
        "modelNumber": "K1614",
        "WarrantyPeriod": "1",
        "ImageUrl": "https://drive.google.com/file/d/1TewNKLoT5H79bAhV4FxLVEWUV9Rg5Ou3",
    },
    {
        "Category": "Kitchen",
        "ProductType": "sinks",
        "ProductName": "single-bowl kitchen sink with 4 faucet holes",
        "modelNumber": "K6546",
        "WarrantyPeriod": "3",
        "ImageUrl": "https://drive.google.com/file/d/1k09CBEJ5IuC-OBC2uhnZZ8qVFfilcAS",
    },
    {
        "Category": "Bathroom",
        "ProductType": "bathroom faucets",
        "ProductName": "2.5 gpm rainhead with wireless speaker",
        "modelNumber": "K9910",
        "WarrantyPeriod": "4",
        "ImageUrl": "https://drive.google.com/file/d/1sHRVdwSdTfRxZIyLxCRDWavoqg0Jvjeu",
    },
    {
        "Category": "Kitchen",
        "ProductType": "kitchen accessories",
        "ProductName": "13-gallon stainless steel step can",
        "modelNumber": "K2094",
        "WarrantyPeriod": "5",
        "ImageUrl": "https://drive.google.com/file/d/1W3qNX8BHos4fn5zqu7SN20YV-hHJXjm8",
    },
    {
        "Category": "Bathroom",
        "ProductType": "toilet seats",
        "ProductName": "66 x 33 freestanding bath with Biscuit exterior",
        "modelNumber": "K2100",
        "WarrantyPeriod": "3",
        "ImageUrl": "https://drive.google.com/file/d/1Q5gWhAstCRrYkb8x4BbaOpHiWSO6ikOe",

    }
]

var Data = [
    {
        "trackingId": "FMPP0255455841",
        "orderNumber": "ORD9866",
        "deliveryStatus ": "DISPATCHED",
        "fName": "Chanakya",
        "lName": "lokam",
        "name": "Chanakya Lokam",
        "dateOfPurchase": "02/22/19",
        "Item": "Cuff Dual-handle wall-mount Kitchen mixer",
        "Qty": "1",
        "Price": "$6,960.00",
        "lineTotal": "$6,960.00",
        "finalTotal": "$6,960.00",
        "warrantyPeriod": "4",
        "ImageUrl": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ-jlZsB_8h27iFRJiOkV1SZHsSFBveXC-RXE8TU0g2evxhYUtQSA",


    },
    {
        "trackingId": "ABDH8393020218",
        "modelNumber": "8956212",
        "orderNumber": "ORD1289",
        "deliveryStatus ": "Shipped",
        "dateOfPurchase": "03/03/19",
        "fName": "pavani",
        "lName": "moturi",
        "name": "Pavani Moturi",
        "Item": "Elate Kitchen sink faucet in Vibrant stainless steel",
        "Qty": "1",
        "Price": "$6,610.00",
        "lineTotal": "$6,610.00",
        "finalTotal": "$6,610.00",
        "warrantyPeriod": "4",
        "ImageUrl": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQi1tWEex9cM8JSXcJJqIMUE1TW36RSbBspVAmA5BBdi1Cfp0EA ",

    },
    {
        "trackingId": "NJTV5643908761",
        "orderNumber": "ORD9765",
        "deliveryStatus ": "COMPLETE",
        "dateOfPurchase": "03/10/19",
        "Item": "40 mm Shower only Trim",
        "Qty": "1",
        "fName": "chanakya",
        "lName": "lokam",
        "name": "Chanakya Lokam",
        "Price": "$3,130.00",
        "lineTotal": "$3,130.00",
        "finalTotal": "$3,130.00",
        "warrantyPeriod": "5",
        "dateOfDelivery": "",
        "ImageUrl": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSAhdI1lEykL_CVE9d9iPnhjEHLwfsjNi9-CN8ws5pGcMeYU3ip1w ",
    },
    {
        "trackingId": "VCTY0345671895",
        "orderNumber": "ORD9874",
        "deliveryStatus ": "Packed",
        "dateOfPurchase": "02/15/19",
        "Item": "Long handle kitchen sink faucet (cyclic valve)",
        "Qty": "1",
        "fName": "akash",
        "lName": "pavate",
        "name": "Akash Pavate",
        "Price": "$1,244.00",
        "lineTotal": "$12,44.00",
        "finalTotal": "$1,244.00",
        "warrantyPeriod": "4",
        "ImageUrl": " https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQGSS4LOFCbZXRfCaYG8ktaL63RjUu--EYv0Be0RdnB-Oqm9RvRYw",

    },
    {
        "trackingId": "BVCF0986236788",
        "orderNumber": "ORD5643",
        "deliveryStatus ": "COMPLETE",
        "dateOfPurchase": "02/17/19",
        "Item": "Dual-handle wall-mount kitchen mixer",
        "Qty": "1",
        "fName": "Akash",
        "lName": "pavate",
        "name": "Akash Pavate",
        "Price": "$15,370.00",
        "lineTotal": "$1,537.00",
        "finalTotal": "$1,537.00",
        "warrantyPeriod": "3",
        "ImageUrl": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTz4JKyq9HmrzgrvPs1uaJTV72m71ZOOnUvw_xZw8N985L4n39Zcw",
    }
]
var Info = [

    {
        "type": "Showers",
        "warrantyPeriod": "2 ",
        "info": "Everything you need to create the perfect shower which gives you a joy in soothing with hot steams",
        "url": "https://www.us.kohler.com/us/Browse-Kohler-Showers/article/CNT126400004.htm#replace",
        "modelNumber": "K3729"
    },
    {
        "type": "Sinks",
        "warrantyPeriod": "1 ",
        "info": "Thoughtful designs that increase everyday efficiency.",
        "url": "https://www.us.kohler.com/us/kitchen-sinks/article/CNT126100002.htm",
        "modelNumber": "K2006"
    },
    {
        "type": "Faucets",
        "warrantyPeriod": "1 ",
        "info": "Thoughtfully designed to add beauty and efficiency to your kitchen.",
        "url": "https://www.us.kohler.com/us/kitchen-faucets/article/CNT125900008.htm",
        "modelNumber": "K1029",
    },
    {
        "type": "Bathtubs",
        "warrantyPeriod": "3 ",
        "info": "Find your perfect bath with an elegant and iconic look in your bathroom experiencing a spa-like experience in your bathroom ",
        "url": "https://www.us.kohler.com/us/browse/bathroom-bathing/_/N-255v",
        "modelNumber": "K9203"

    }
]
server.use(restify.conditionalRequest());
//var bot = new builder.UniversalBot(connector);
var bot = new builder.UniversalBot(connector, {
    storage: new builder.MemoryBotStorage()
});
var onum, onumber;
var model = 'https://westus.api.cognitive.microsoft.com/luis/v2.0/apps/58b0417a-ffec-4c4e-85ef-5d7bb1f57de0?verbose=true&timezoneOffset=-360&subscription-key=32b34f6f417546c5ad276f3e5640729a&q='
var recognizer = new builder.LuisRecognizer(model);
var dialog = new builder.IntentDialog({
    recognizers: [recognizer]
});
var count = 0;
var n = 0;
server.post('/api/messages', connector.listen());
bot.dialog('/', dialog);

server.get(/.*/, restify.serveStatic({
    'directory': __dirname + '/',
    'default': 'main.html'
}));
function getCardsAttachments2(session) {
    return [
        new builder.HeroCard(session)
            .buttons([
                builder.CardAction.imBack(session, "Retrieve Order Status", "Retrieve Order Status"),
                builder.CardAction.imBack(session, 'Request Shipping & Delivery Status', "Request Shipping & Delivery Status"),
                builder.CardAction.imBack(session, 'Provide Warranty Information', "Provide Warranty Information"),
                builder.CardAction.imBack(session, 'Provide nearby Stores Information', "Provide nearby Stores Information"),
                builder.CardAction.imBack(session, 'Identify Product', "Identify Product"),
                builder.CardAction.imBack(session, 'Anything Else', 'Anything Else')

            ]),
    ];
}
function createReceiptCard4(session) {
    return new builder.ReceiptCard(session)
        .title(session.name)
        .facts([
            builder.Fact.create(session, session.orderNumber, 'Order Number'),
            builder.Fact.create(session, session.dateOfPurchase, 'Date of Purchase'),
            builder.Fact.create(session, session.Item, 'Item'),
            builder.Fact.create(session, session.Qty, 'Quantity'),
            builder.Fact.create(session, session.lineTotal, 'Line Total'),
        ])
        .total(session.finalTotal)
}
function getCardsAttachments3(session) {
    //console.log("Session ", session);
    return [
        new builder.HeroCard(session)
            .title('Name: ' + session.name)
            .subtitle('Date of Purchase : ' + session.dateOfPurchase)
            .buttons([
                builder.CardAction.imBack(session, session.orderNumber, session.orderNumber)

            ]),
    ];
}
function DetectionCard1(session) {
    //  //console.log("Session ", session);
    return [
        new builder.HeroCard(session)
            .title(session.type)
            .subtitle(session.info)
    ];
}
function storeLocator(session) {
    //console.log("Session ", session);
    return [
        new builder.HeroCard(session)
            .title(" Here is the nearby store address ")
            .text("45625 Grand River Ave, Novi, MI 48374, USA")
    ];
}
function WarrentyCard4(session) {
    return [
        new builder.HeroCard(session)
            .buttons([
                // builder.CardAction.imBack(session, "Bar faucets", "Bar faucets"),
                builder.CardAction.imBack(session, "Kitchen faucets", "Kitchen faucets"),
                builder.CardAction.imBack(session, "Sinks", "Sinks"),
                builder.CardAction.imBack(session, "Kitchen accessories", "Kitchen accessories"),
            ]),
    ];
}
function WarrentyCard3(session) {
    return [
        new builder.HeroCard(session)
            .buttons([
                builder.CardAction.imBack(session, "Bathroom sinks", "Bathroom Sinks"),
                builder.CardAction.imBack(session, "Bathroom faucets", "Bathroom Faucets"),
                builder.CardAction.imBack(session, "Toilet seats", "Toilet Seats")
            ]),
    ];
}
function WarrentyCard2(session) {
    return [
        new builder.HeroCard(session)
            .buttons([
                builder.CardAction.imBack(session, "Bathroom", "Bathroom"),
                builder.CardAction.imBack(session, "Kitchen", "Kitchen"),
            ]),
    ];
}
function WarrentyCard1(session) {
    return [
        new builder.HeroCard(session)
            .text()
            .buttons([
                builder.CardAction.imBack(session, "Model Number", "Model Number"),
                builder.CardAction.imBack(session, "Upload Image", "Upload Image"),
                builder.CardAction.imBack(session, "Other", "Other")

            ]),
    ];
}
// function createReceiptCard1(session) {
//     return new builder.ReceiptCard(session)
//         .buttons([
//             builder.CardAction.openUrl(session, 'https://www.us.kohler.com/us/storelocator/storeLocator.jsp', 'Store locator')
//         ]);
// }
function createReceiptCard(session) {
    //console.log("Image URL in Recipt card", session);
    return new builder.ReceiptCard(session)
        .title(session.name)
        .facts([
            builder.Fact.create(session, session.orderNumber, 'Order Number'),
            builder.Fact.create(session, session.dateOfPurchase, 'Date of Purchase'),
        ])
        .items([
            builder.ReceiptItem.create(session, '', ' ')
                .image(builder.CardImage.create(session, session.ImageUrl))
        ])
        .total(session.finalTotal)
}
// function getCardsAttachments(session) {
//     //console.log("getCardsAttachments", session)
//     return [
//         new builder.HeroCard(session)
//             .title('Order Number : ' + session.orderNumber)
//             .subtitle('Name: ' + session.name)
//             .text("Date of Purchase : " + session.dateOfPurchase + " \n Item : " + session.Item + " \n Quantity : " + session.Qty + " \n Line Total : " + session.lineTotal + " \n Final Total : " + session.finalTotal)];
// }
bot.on('conversationUpdate', function (message) {
    if (message.membersAdded) {

        message.membersAdded.forEach(function (identity) {
            //  //console.log("Message in initial message" ,message);
            if (identity.id == message.address.bot.id) {
                var reply = new builder.Message()
                    .address(message.address)
                    .text("Hi, I'm William - The Agent Assistance Bot. I can help you answer most common queries of customers.");
                bot.send(reply);
            }
        });
    }
});
const HeroCardName = 'Hero card';
const ThumbnailCardName = 'Thumbnail card';
const ReceiptCardName = 'Receipt card';
const ReceiptCardName1 = 'Reciept Card1';
const SigninCardName = 'Sign-in card';
const CardNames = [HeroCardName, ThumbnailCardName, ReceiptCardName, SigninCardName];
function createCard(selectedCardName, session) {
    switch (selectedCardName) {

        case ReceiptCardName:
            return createReceiptCard(session);
        default:
            return createReceiptCard(session);
    }
}
//Greetings intent matches
dialog.matches('Greetings', [
    function (session, args) {
        session.sendTyping();
        //   session.send("Hello ** You **");
        session.send("Hey " + session.message.user.id + "! How can I help you today?");

    }
]);
//Capabilities intent matches
dialog.matches('Capabilities', [
    function (session, args) {
        session.sendTyping();
        session.send("I can help you with the following")
        var cards = getCardsAttachments2();
        var reply = new builder.Message(session)
            .attachmentLayout(builder.AttachmentLayout.carousel)
            .attachments(cards);
        session.send(reply);

    }

]);
dialog.matches('anythingElse', [
    function (session, args) {
        session.sendTyping();
        session.send("Sure, let me know what I can help you with?")
    }

]);

dialog.matches('Detection', [
    function (session, args) {

        session.sendTyping();
        session.beginDialog('/DetectionSenario', session)

    }

]);
bot.dialog('/DetectionSenario', [
    function (session, args) {
        session.sendTyping();
        builder.Prompts.text(session, "I can help you identify products by taking a look at an image of it. Do you have any image that I can see? ");
        var cards = warrentyModel(session);
        var reply = new builder.Message(session)
            .attachmentLayout(builder.AttachmentLayout.carousel)
            .attachments(cards);
        session.send(reply);
    },
    function (session, args) {
        if (args.response == 'Yes') {

            session.beginDialog('/IdentificationSenario', session)
        }
        else {
            session.send("Oh. I believe I cannot help you without an image as of yet. But my developers usually update my features regularly. So, please check back with me later");
            session.endDialog();
            session.endConversation();
        }



    },
])
bot.dialog('/IdentificationSenario', [
    function (session, args) {
        session.sendTyping();
        builder.Prompts.attachment(session, "Please use the upload image button on the bottom left side of the chat window to upload an image of the product ");

    },
    function (session, args) {
        //console.log("args in Identification", args);
        //console.log("session in Identifiaction", session);
        const options = {
            method: 'POST',
            uri: 'https://southcentralus.api.cognitive.microsoft.com/customvision/v2.0/Prediction/80999621-c691-476c-9c8a-de944b4f5e1c/url?iterationId=91ded2b8-2bbd-4896-8612-bc3559c61a32',
            json: true,
            body: {
                "Url": args.response[0].contentUrl
            },
            headers: {
                "Prediction-Key": "057d63aa92d24a46992fb48cc477c499",
                "Content-Type": "application/json"
            }
        }
        request(options)
            .then(response => {
                Info.forEach(element => {
                    //console.log("element", element);
                    if (element.type == response.predictions[0].tagName) {
                        //console.log("response.predictions[0].tagName", response.predictions[0].tagName);
                        session.type = element.type
                        session.url = element.url
                        session.info = element.info

                    }

                });
                //console.log("Session After adding ", session);
                session.send(" I see that the picture is of a product that falls in the category of " + session.type + ". Here's some more information about these kinds of products.");
                var cards = DetectionCard1(session);
                var reply = new builder.Message(session)
                    .attachmentLayout(builder.AttachmentLayout.carousel)
                    .attachments(cards);
                session.send(reply);
                session.endDialog();
                session.endConversation();
            })
    }
])




//order Number
dialog.matches('OrderNum', [
    function (session, args) {
        session.sendTyping();
        //console.log("args in order number", args);
        onum = args.entities[0].entity;
        onumber = onum.toUpperCase();
        Data.forEach(element => {
            if (element.orderNumber == onumber) {
                globalOrder = onumber;
                session.orderNumber = element.orderNumber
                session.dateOfPurchase = element.dateOfPurchase
                session.fName = element.fName
                session.lName = element.lName
                session.finalTotal = element.finalTotal
                session.Item = element.Item
                session.Qty = element.Qty
                session.name = element.name
                session.lineTotal = element.lineTotal
                session.ImageUrl = element.ImageUrl
                var selectedCardName = createReceiptCard
                var card = createCard(selectedCardName, session);
                var msg = new builder.Message(session).addAttachment(card);
                session.send(msg);

            }

        });


    }

]);

//OrderStats 

dialog.matches('Order', [
    function (session, args) {
        //  //console.log("session", session);

        session.sendTyping();
        if (args.entities.length == 0) {
            session.beginDialog('/orderWithDetails', session)

        }
        else {
            //console.log("args", args)
            var count = 0;
            if (args.entities[0].type == "builtin.personName") {
                Data.forEach(element => {
                    //console.log("Inside for");
                    if (element.lName == args.entities[0].entity) {
                        //console.log("inside if", count);
                        count++;
                    }
                });
                //console.log("After for", count);
                if (count == 1) {

                    //console.log("inside count =1");
                    Data.forEach(element => {
                        if (element.lName == args.entities[0].entity) {
                            session.orderNumber = element.orderNumber
                            session.dateOfPurchase = element.dateOfPurchase
                            session.fName = element.fName
                            session.lName = element.lName
                            session.finalTotal = element.finalTotal
                            session.Item = element.Item
                            session.Qty = element.Qty
                            session.name = element.name
                            session.lineTotal = element.lineTotal
                            session.ImageUrl = element.ImageUrl
                            var selectedCardName = createReceiptCard
                            var card = createCard(selectedCardName, session);
                            var msg = new builder.Message(session).addAttachment(card);
                            session.send(msg);

                        }
                    });
                }
                else if (count == 0) {
                    session.send("We didn't find any orders with that order number");
                }
                else {
                    session.send("We fetched " + count + " orders with the given last name")
                    Data.forEach(element => {
                        if (element.lName == args.entities[0].entity) {
                            //  var orderSession = element.orderNumber;
                            session.orderNumber = element.orderNumber
                            session.dateOfPurchase = element.dateOfPurchase
                            session.fName = element.fName
                            session.lName = element.lName
                            session.finalTotal = element.finalTotal
                            session.Item = element.Item
                            session.Qty = element.Qty
                            session.name = element.name
                            session.lineTotal = element.lineTotal
                            session.ImageUrl = element.ImageUrl
                            session.count = count;
                            var cards = getCardsAttachments3(session);
                            var reply = new builder.Message(session)
                                .attachmentLayout(builder.AttachmentLayout.carousel)
                                .attachments(cards);
                            session.send(reply);
                            //session.beginDialog('/orderDetailsForLastname', session)

                        }
                    });

                }

            }
            else {
                var c = 0;
                onum = args.entities[0].entity;
                onumber = onum.toUpperCase();
                //console.log("onumber", onumber);
                Data.forEach(element => {
                    if (element.orderNumber == onumber) {
                        c++;
                    }

                });
                if (c == 0) {
                    session.send("We didn't find any orders with that order number");
                }
                else {
                    Data.forEach(element => {
                        if (element.orderNumber == onumber) {
                            var orderSession = element.orderNumber;
                            session.orderNumber = element.orderNumber
                            session.dateOfPurchase = element.dateOfPurchase
                            session.fName = element.fName
                            session.lName = element.lName
                            session.finalTotal = element.finalTotal
                            session.Item = element.Item
                            session.Qty = element.Qty
                            session.name = element.name
                            session.lineTotal = element.lineTotal
                            session.ImageUrl = element.ImageUrl
                            var selectedCardName = createReceiptCard
                            var card = createCard(selectedCardName, session);
                            var msg = new builder.Message(session).addAttachment(card);
                            session.send(msg);
                        }

                    });


                }
            }

            // session.send(" Still Working for Number");
        }

    }
]);
// bot.dialog('/orderDetailsForLastname', [
//     function (session, args) {
//         session.sendTyping();
//         console.log("inside orderDetailsForLastname");
//        // session.send("We fetched " + session.count + " orders with the given last name")
    
//     },
//     function (session, args) {
//         console.log("args", args);
//         session.send("Still Working");
//         session.endDialog();
//         session.endConversation();

//     }
   

// ])

bot.dialog('/orderWithDetails', [

    function (session, args) {
        session.sendTyping();
        builder.Prompts.text(session, "Please enter the customer's order number");
    },
    function (session, args) {
       // //console.log("args", args);
        Data.forEach(element => {
            onum = args.response;
            onumber = onum.toUpperCase()
            if (element.orderNumber == onumber) {
                globalOrder = onumber;
                count++;
            }
        });
        if (count == 1) {
            Data.forEach(element => {

                if (element.orderNumber == onumber) {
                    session.orderNumber = onumber
                    session.dateOfPurchase = element.dateOfPurchase
                    session.fName = element.fName
                    session.lName = element.lName
                    session.finalTotal = element.finalTotal
                    session.Item = element.Item
                    session.Qty = element.Qty
                    session.name = element.name
                    session.lineTotal = element.lineTotal
                    session.ImageUrl = element.ImageUrl
                    var selectedCardName = createReceiptCard
                    var card = createCard(selectedCardName, session);
                    var msg = new builder.Message(session).addAttachment(card);
                    session.send(msg);

                }
            });
        }
        else if (count == 0) {
            session.send("We didn't find any orders with that order number");


        } else {
            Data.forEach(element => {
                if (element.orderNumber == onumber) {
                    session.orderNumber = onumber
                    session.dateOfPurchase = element.dateOfPurchase
                    session.fName = element.fName
                    session.lName = element.lName
                    session.finalTotal = element.finalTotal
                    session.Item = element.Item
                    session.Qty = element.Qty
                    session.name = element.name
                    session.lineTotal = element.lineTotal
                    session.ImageUrl = element.ImageUrl
                    var selectedCardName = createReceiptCard
                    var card = createCard(selectedCardName, session);
                    var msg = new builder.Message(session).addAttachment(card);
                    session.send(msg);

                }
            });

        }
        session.endDialog();
        session.endConversation();
    }

]);

dialog.matches('Warranty', [
    function (session, args) {
        session.sendTyping();
       // //console.log("args", args);
        session.send("Sure, I can help you retrieve warranty information.");
        session.beginDialog('/Warrenty1', session)
    }
]);
bot.dialog('/Warrenty1', [
    function (session, args) {
        session.sendTyping();
        builder.Prompts.text(session, "Do you happen to know the model number of the product?");
        var cards = warrentyModel(session);
        var reply = new builder.Message(session)
            .attachmentLayout(builder.AttachmentLayout.carousel)
            .attachments(cards);
        session.send(reply);
    },
    function (session, args) {
       // ////console.log("args in Warrenty1", args.response);
        if (args.response == "Yes") {
            session.beginDialog('/warrentyWithModelNumber', session)
        }
        else {
            builder.Prompts.text(session, "Do you have an image of the product?");
            var cards = warrentyModel(session);
            var reply = new builder.Message(session)
                .attachmentLayout(builder.AttachmentLayout.carousel)
                .attachments(cards);
            session.send(reply);
        }



    },
    function (session, args) {
        ////console.log("==============================");
        ////console.log("args", args);
        if (args.response == 'Yes') {
            session.beginDialog('/UploadImage', session)
        }
        else {
            if (args.response == 'No') {
                session.send("Ok, I would need answers to a couple of questions to better assist you.");
                session.beginDialog('/OtherforWarranty', session)
            }
            else {
                ////console.log("Required condition");
            }

        }
    }
])
bot.dialog('/UploadImage', [
    function (session, args) {
        session.sendTyping();
        builder.Prompts.attachment(session, " Please use the upload image button on the bottom left side of the chat window to upload an image of the product that you're looking for ");
    },
    function (session, args) {
        //console.log("args", args);
        session.sendTyping();
        session.send("Give me a second. Let me try recognize the product in the picture.");
        const options = {
            method: 'POST',
            uri: 'https://southcentralus.api.cognitive.microsoft.com/customvision/v2.0/Prediction/80999621-c691-476c-9c8a-de944b4f5e1c/url?iterationId=91ded2b8-2bbd-4896-8612-bc3559c61a32',
            json: true,
            body: {
                "Url": args.response[0].contentUrl
            },
            headers: {
                "Prediction-Key": "057d63aa92d24a46992fb48cc477c499",
                "Content-Type": "application/json"
            }
        }
        request(options)
            .then(response => {
                Info.forEach(element => {
                    //console.log("element", element);
                    if (element.type == response.predictions[0].tagName) {
                        //console.log("response.predictions[0].tagName", response.predictions[0].tagName);
                        //session.send(" The warranty period of " + element.type + " with model number" + element.modelNumber + " is " + element.warrantyPeriod + " from Date of Purchase ");
                        session.send("I was able to recognize this product and it falls in the category of " + element.type.toUpperCase() + " with model number " + element.modelNumber + ". This product comes with a warranty of " + element.warrantyPeriod + " year(s) from the date of purchase.");
                    }

                });
                session.endDialog();
                session.endConversation();
            })


        // session.endDialog();
        //   session.endConversation();

    }


])
bot.dialog('/OtherforWarranty', [
    function (session, args) {
        session.sendTyping();
        builder.Prompts.text(session, "Where is the product located?");
        var cards = WarrentyCard2(session);
        var reply = new builder.Message(session)
            .attachmentLayout(builder.AttachmentLayout.carousel)
            .attachments(cards);
        session.send(reply);
    },
    function (session, args) {
        //console.log("args in OtherforWarranty", args.response);
        if (args.response == "Bathroom") {
            session.beginDialog('/bathroomInfo', session)
        }
        if (args.response == "Kitchen") {

            session.beginDialog('/kitchenInfo', session)

        }



        session.endDialog();
        session.endConversation();

    },


])

bot.dialog('/bathroomInfo', [
    function (session, args) {
        session.sendTyping();
        builder.Prompts.text(session, " What is the product type?");
        var cards = WarrentyCard3(session);
        var reply = new builder.Message(session)
            .attachmentLayout(builder.AttachmentLayout.carousel)
            .attachments(cards);
        session.send(reply);
    },

])
bot.dialog('/kitchenInfo', [
    function (session, args) {
        session.sendTyping();
        builder.Prompts.text(session, " What is the product type?");
        var cards = WarrentyCard4(session);
        var reply = new builder.Message(session)
            .attachmentLayout(builder.AttachmentLayout.carousel)
            .attachments(cards);
        session.send(reply);
    },
    function (session, args) {
        //console.log("args", args);

        session.endDialog();
        session.endConversation();

    },
])


dialog.matches('BathroomItems', [
    function (session, args) {
        session.sendTyping();
        //console.log("args in Bathroom Items", args);
        Data1.forEach(element => {
            if (element.ProductType == args.entities[0].entity) {
                session.send(element.ProductType.toUpperCase() + " come with a warranty of " + element.WarrantyPeriod + " year(s) from the date of purchase");
                //session.send(" The warranty period of  " + element.ProductType + " is " + element.WarrantyPeriod + " from Date of purchase ")
            }
        });


    }
])
dialog.matches('KitchenItems', [
    function (session, args) {
        session.sendTyping();
        // //console.log("args in Kitchen Items", args);
        Data1.forEach(element => {
            //console.log(args.entities[0].entity, element.ProductType);
            // //console.log("args.entities[0].entity",args.entities[0].entity);
            //console.log("element.ProductType == args.entities[0].entity", element.ProductType == args.entities[0].entity);
            if (element.ProductType == args.entities[0].entity) {
                session.send(element.ProductType.toUpperCase() + " come with a warranty of " + element.WarrantyPeriod + " year(s) from the date of purchase");
                // session.send(" The warranty period of  " + element.ProductType + " is " + element.WarrantyPeriod + " form Date of Purchase")
            }
        });



    }

]);
function warrentyModel(session) {
    return [
        new builder.HeroCard(session)
            .buttons([
                builder.CardAction.imBack(session, "Yes", "Yes"),
                builder.CardAction.imBack(session, "No", "No"),
            ]),
    ];
}
bot.dialog('/warrentyWithModelNumber', [
    function (session, args) {
        session.sendTyping();
        builder.Prompts.text(session, "Can you please enter the model number of the product?");
    },
    function (session, args) {
        //console.log("args in warrentyWithModelNumber", args);

        Info.forEach(element => {
            if (element.modelNumber == args.response.toUpperCase()) {
                //console.log("%%%%%%%%%%%%%%%%%%%%%%%%%%%")
                session.send("I see that the " + element.modelNumber + " relates to a model of " + element.type + ". This product comes with a warranty of " + element.warrantyPeriod + " year(s) from the date of purchase");

            }

        });
        session.endDialog();
        session.endConversation();
        // session.send("Adding");
        //
    }
])

bot.dialog('/WarrantywithDetails', [
    function (session, args) {
        session.sendTyping();
        var cards = WarrentyCard1(session);
        var reply = new builder.Message(session)
            .attachmentLayout(builder.AttachmentLayout.carousel)
            .attachments(cards);
        session.send(reply);
        session.endDialog();
        session.endConversation();
        //builder.Prompts.text(session, "Enter product model number or upload the image");
    },


])

dialog.matches('Delivery', [
    function (session, args) {
        session.sendTyping();
        //console.log("args", args);
        var oNumber;
        var str;
        if(globalOrder == null)
        {
            session.beginDialog('/DeliverywithDetails', session)
        }
        else
        {
            if (args.entities.length == 0) {
                //console.log("globalOrder", globalOrder);
                if (globalOrder == null) {
                    session.beginDialog('/DeliverywithDetails', session)
    
                }
                else {
                    //console.log("globalOrder", globalOrder);
                    Data.forEach(element => {
    
                        if (element.orderNumber == globalOrder) {
                            oNumber = element.orderNumber;
                            str = element["deliveryStatus "]
                            flag++;
    
                        }
    
                    });
                    if (flag == 0) {
                        session.send("We didn't find any orders with the giver order number");
                    }
                    else {
                        session.send("Delivery status of the order " + oNumber + " is " + str);
    
                    }
    
                }
    
    
            }
            else {
                var str;
                //console.log(" @@@@@@@@@@@@@@@@@@@@@@@@@@@")
                //console.log("ags", args);
                var flag = 0;
                onum = args.entities[0].entity;
                onumber = onum.toUpperCase()
                Data.forEach(element => {
    
                    if (element.orderNumber == onumber) {
                        str = element["deliveryStatus "]
                        flag++;
    
                    }
    
                });
                if (flag == 0) {
                    session.send("We didn't find any orders with the giver order number");
                }
                else {
                    session.send("Delivery status of the order " + onumber + " is " + str);
    
                }
            }
        }
       
   

    }
]);
bot.dialog('/DeliverywithDetails', [
    function (session, args) {
        session.sendTyping();
        builder.Prompts.text(session, "Enter customer order number");
    },
    function (session, args) {
        var str;
        //console.log("args", args);
        var count = 0;
        onum = args.response;
        onumber = onum.toUpperCase();
        globalOrder = args.response;
        Data.forEach(element => {

            if (element.orderNumber == onumber) {
                str = element["deliveryStatus "]
                count++;


            }
        });
        if (count == 0) {
            session.send("We didn't find any orders with the given number");
        } else {
            session.send("Delivery status of the order " + onumber + "  is " + str);

        }
        session.endDialog();
        session.endConversation();

    }


])

dialog.matches('Tracking', [
    function (session, args) {
        session.sendTyping();
        //console.log("args", args);
        var oNumber;
        var str;
        if (args.entities.length == 0) {
            //console.log("globalOrder", globalOrder);
            if (globalOrder == null) {
                session.beginDialog('/TrackingwithDetails', session)

            }
            else {
                //console.log("globalOrder", globalOrder);
                Data.forEach(element => {

                    if (element.orderNumber == globalOrder) {
                        oNumber = element.orderNumber;
                        str = element.trackingId
                        flag++;

                    }

                });
                if (flag == 0) {
                    session.send("We didn't find any orders with the giver order number");
                }
                else {
                    session.send("Tracking ID of the order " + oNumber + " is " + str);

                }

            }


        }
        else {
            var str;
            //console.log(" @@@@@@@@@@@@@@@@@@@@@@@@@@@")
            //console.log("ags", args);
            var flag = 0;
            onum = args.entities[0].entity;
            onumber = onum.toUpperCase()
            Data.forEach(element => {

                if (element.orderNumber == onumber) {
                    str = element.trackingId
                    flag++;

                }

            });
            if (flag == 0) {
                session.send("We didn't find any orders with the giver order number");
            }
            else {
                session.send("Tracking ID of the order " + onumber + " is " + str);

            }
        }

    }
]);
bot.dialog('/TrackingwithDetails', [
    function (session, args) {
        session.sendTyping();
        builder.Prompts.text(session, "Enter customer order number");
    },
    function (session, args) {
        var str;
        //console.log("args", args);
        var count = 0;
        onum = args.response;
        onumber = onum.toUpperCase()
        Data.forEach(element => {

            if (element.orderNumber == onumber) {
                str = element.trackingId
                count++;


            }
        });
        if (count == 0) {
            session.send("We didn't find any orders with the given number");
        } else {
            session.send("Tracking ID of the order " + onumber + "  is " + str);

        }
        session.endDialog();
        session.endConversation();

    }


])
dialog.matches('StoreLocator', [
    function (session, args) {
        console.log("Inside store locator");
        session.sendTyping();
        var cards = storeLocator(session);
        var reply = new builder.Message(session)
            .attachmentLayout(builder.AttachmentLayout.carousel)
            .attachments(cards);
        session.send(reply);;
        session.endDialog();
        session.endConversation();
        // session.send("Working on store locater");
    }
]);

dialog.matches('Thankyou', [
    function (session, args) {
        session.sendTyping();
        //console.log("--------------------------------------------------------");
        //console.log(moment().format('MMMM Do YYYY, hh🇲🇲ss a') + " | Thank you Intent Matched");
        //console.log("--------------------------------------------------------");
        session.send("My pleasure! Let me know if you need anything else.");
    }
]);

dialog.matches('conformation', [
    function (session, args) {
        session.sendTyping();
        //console.log("--------------------------------------------------------");
        //console.log(moment().format('MMMM Do YYYY, hh🇲🇲ss a') + " | Thank you Intent Matched");
        //console.log("--------------------------------------------------------");
        session.send("Thanks, have a great day!");
    }
]);

dialog.onDefault(builder.DialogAction.send("Sorry, I am having trouble understanding you. Can you please repeat again."));